const Input = () => {
  return (
    <div>
      <input >
    </div>
  )
}

export default Input